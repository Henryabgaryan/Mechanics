import org.xml.sax.helpers.AttributesImpl;
import java.lang.Math; // importing java.lang package
import java.util.*;


import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Main {
    // masses of the objects
    static double M1 = 0;
    static double[] InitialPositionM1 = {0,0};
    static double M2 = 0;
    static double[] InitialPositionM2 = {0,0};
    static double M3 = 0;
    static double[] InitialPositionM3 = {0,0};


    //frictions of the objects
    static double myu1 = 0;
    static double myu2 = 0;
    static double myu3 = 0;

    //Force
    static double F = 0;

    //time moment  `=
    static double t = 0;

    //gravity
    final static double g = 10;

    //number of values to be received from the user


    //table of forces at specific time moment
    static double[][] TimeAndForce;


    public static void main(String[] args) {



       Input();


       //animated experiment

        JFrame frame = new JFrame();
        ImageIcon icon = new ImageIcon("diagram_gif.gif");
        JLabel label = new JLabel(icon);
        frame.add(label);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }



    public static void Input(){

        Scanner sc = new Scanner(System.in);


        System.out.println("How many time and force pairs do you want to input? Notice that you must input at least 2 pairs");
        int n = sc.nextInt();

        double[][] force_time_pairs = new double[n][2];
        TimeAndForce = force_time_pairs;

        for (int i = 0; i < n; i++) {

            System.out.println("Input the time moment in seconds ");
            t = sc.nextDouble();
            //putting time moment in respective table cell
            TimeAndForce[i][0] = t;

            System.out.println("Input the respective force (in Newtons) of time moment " + t + " .");
            System.out.println("You must input force between -300N  and 300N included! ");
            F = sc.nextDouble();

            while(F < -300 || F > 300){
                System.out.println("Please input force from the specified range! ");
                System.out.println("You must input force between -300N  and 300N included! ");
                F = sc.nextDouble();
            }
                //putting force in respective table cell
                TimeAndForce[i][1] = F;
        }

        System.out.println("Now you must input masses of the objects and their initial positions. ");

        //getting mass and initial position of object 1
        System.out.println("Input mass M1 of object 1.You must input mass between 0kg  and 10kg  included!");
        M1 = sc.nextDouble();
        while(M1 < 0 || M1 > 10){
            System.out.println("Mass of M1 is invalid!");
            System.out.println("You must input mass between 0kg  and 10kg  included!");
            M1 = sc.nextDouble();
        }


        System.out.println("Input the initial position of the object M1. ");
        System.out.println("Notice that you must input 2 numbers (x and y coordinates).");
        double x = sc.nextDouble();
        double y = sc.nextDouble();
        InitialPositionM1[0] = x;
        InitialPositionM1[1] = y;


        //getting mass and initial position of object 2
        System.out.println("Input mass M2 of object 2. You must input mass between 0kg  and 10kg  included!");
        M2 = sc.nextDouble();
        while(M2 < 0 || M2 > 10){
            System.out.println("Mass of M2 is invalid!");
            System.out.println("You must input mass between 0kg  and 10kg  included!");
            M2 = sc.nextDouble();
        }
        System.out.println("Input the initial position of the object M2.");
        System.out.println("Notice that you must input 2 numbers (x and y coordinates).");
         x = sc.nextDouble();
         y = sc.nextDouble();
        InitialPositionM2[0] = x;
        InitialPositionM2[1] = y;



        //getting mass and initial position of object 3
        System.out.println("Input mass M3 of object 2. You must input mass between 0kg  and 10kg  included!");
        M3 = sc.nextDouble();
        while(M3 < 0 || M3 > 10){
            System.out.println("Mass of M3 is invalid!");
            System.out.println("You must input mass between 0kg and 10kg  included!");
            M3 = sc.nextDouble();
        }
        System.out.println("Input the initial position of the object M3.");
        System.out.println("Notice that you must input 2 numbers (x and y coordinates).");
        x = sc.nextDouble();
        y = sc.nextDouble();
        InitialPositionM3[0] = x;
        InitialPositionM3[1] = y;


        System.out.println("Now you must input frictions");
        System.out.println("You must input frictions between 0 and 0.5 included!");

        System.out.println("Please input friction myu1 between object M1 and table");
        myu1 = sc.nextDouble();
        while(myu1 < 0 || myu1 > 0.5){
            System.out.println("You must input mass between 0 and 0.5 included!");
            myu1 = sc.nextDouble();
        }

        System.out.println("Please input friction myu2 between object M1 and M2");
        myu2 = sc.nextDouble();
        while(myu2 < 0 || myu2 > 0.5){
            System.out.println("You must input mass between 0 and 0.5 included!");
            myu2 = sc.nextDouble();
        }

        System.out.println("Please input friction myu3 between object M1 and M3");
        myu3 = sc.nextDouble();
        while(myu3 < 0 || myu3 > 0.5){
            System.out.println("You must input mass between 0 and 0.5 included!");
            myu3 = sc.nextDouble();
        }

        System.out.println("At what time moment would you like to see the dispositions of M1, M2 and M3");
        t = sc.nextDouble();
        Disposition(t);




        sc.close();




    }

    public static double Interpolate(double value){


        double result = 0;
        int n = TimeAndForce.length;

        //Sorting the 2D array TimeandForce by time component
        java.util.Arrays.sort(TimeAndForce, (a, b) -> Double.compare(a[0], b[0]));


        if(value < TimeAndForce[0][0] ){

            result = TimeAndForce[0][1] + (value - TimeAndForce[0][0] )*(TimeAndForce[1][1] - TimeAndForce[0][1])/(TimeAndForce[1][0] - TimeAndForce[0][0]);

        } else if(value > TimeAndForce[n-1][0]){

            result = TimeAndForce[n-2][1] + (value - TimeAndForce[n-2][0])*(TimeAndForce[n-1][1] - TimeAndForce[n-2][1])/(TimeAndForce[n-1][0] - TimeAndForce[n-2][0]);

        }else {

            for (int i = 0; i < n - 1; i++) {

                if (value >= TimeAndForce[i][0] && value <= TimeAndForce[i + 1][0]) {

                    result = TimeAndForce[i][1] + (value - TimeAndForce[i][0]) * (TimeAndForce[i + 1][1] - TimeAndForce[i][1]) / (TimeAndForce[i + 1][0] - TimeAndForce[i][0]);

                } else {
                    System.out.println();
                }
            }
        }

        return result;

    }


    public  static void Disposition(double atTime){




        double a2 = (-(M1+M3)*(myu2*M2*g - M3*g + 2*myu3*Interpolate(atTime)) + M3*(myu2*M2*g - myu1*M1*g + myu1*myu2*M2*g)) / (M2*(M1+M3) - M3*(-M2 + myu1*M2-M1-M3)) ;
        double a1  = (-M2*a2 + myu2*M2*g - myu1*M1*g + myu1*M2*a2 + myu1*myu2*M2*g)/(M1+M2);

        InitialPositionM1[0] = InitialPositionM1[0] + 0.5 * a1 *Math.pow(atTime, 2);

        InitialPositionM2[0] = InitialPositionM2[0] + 0.5 * a2 *Math.pow(atTime, 2);
        InitialPositionM2[1] = InitialPositionM2[1] + 0.5 * a2 *Math.pow(atTime, 2);

        InitialPositionM3[1] = InitialPositionM3[1] + 0.5 * a2 *Math.pow(atTime, 2);

        System.out.println("M1 is at position " + "[ " + InitialPositionM1[0] + " ; " +InitialPositionM1[1] + " ]" + " at time " + atTime);
        System.out.println("M2 is at position " + "[ " + InitialPositionM2[0] + " ; " +InitialPositionM2[1] + " ]" + " at time " + atTime);
        System.out.println("M3 is at position " + "[ " + InitialPositionM3[0] + " ; " +InitialPositionM3[1] + " ]" + " at time " + atTime);



    }






}
